#ifndef __MYUTILS_H
#define __MYUTILS_H

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

int factorial(int n);

int isPrime(int a);

int ispalindrome(int m);

double vsum(int a,...);

#endif