#ifndef __MYSTRING_H
#define __MYSTRING_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int mystrlen(char *s1);

char* mystrcat(char *s1,char *s2);

int mystrcmp(char *s1,char *s3);

char* mystrcpy(char *s1,char *s2);

#endif