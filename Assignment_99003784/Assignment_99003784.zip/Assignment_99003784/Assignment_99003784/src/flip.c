#include "bitmask.h"

int flip(int a,int o)
{
    o = ~a;
    return o;
}